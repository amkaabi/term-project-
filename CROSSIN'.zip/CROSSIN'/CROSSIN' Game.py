import pygame



import random 



pygame.init()


pygame.font.init()
############  pics ######################
#https://freeartbackgrounds.com/?1318,sand-from-desert-background
#sand background
backPicDes="sand.png"
#https://www.chupamobile.com/ui-graphic-asset/3
#-set-nature-and-desert-game-background-14764
#mainpage link
dMainPgPic='desertMainpg.png'
#https://www.behance.net/gallery/46601081/Background-for-mobile-game
mMainPgPic='mMainPic.jpg'
#https://www.dexigner.com/news/32195
mBg1='staries2mac.jpg'
mBg2='stariesMac.jpg'
mBg3='Macdist.jpg'
#
goastLeft=10*['gleft1.png','gleft2.png','gleft3.png','gleft4.png']
goastRight=10*['gright1.png','gright2.png','gright3.png','gright4.png']
#https://ya-webdesign.com/download.html scorpion right and left
scorpionLeft=10*['sleft1.png','sleft2.png','sleft3.png',
'sleft4.png','sleft5.png','sleft6.png']
scorpionRight=10*['sright1.png','sright2.png','sright3.png',
'sright4.png','sright5.png','sright6.png']
#http://pngimg.com/download/82061 KFC 
kfcLeft=5*['kfcLeft.png']
kfcRight=5*['kfcRight.png']
#https://www.cleanpng.com/png-doner-kebab-turkish-cuisine-shawarma-fajita-kebab-4091996/
#shawarma
shawarmaRight=5*['shRight.png']
shawarmaLeft=5*['shLeft.png']
#sharkPic
sharkRight=5*['sharkRIGHT.png']
sharkLeft=5*['sharkLEFT.png']

fishRight=5*['RightFish.png']
fishLeft=5*['leftFish.png']
#http://clipart-library.com/cartoon-scuba-diver-pictures.html
diverRight=5*['diveRight.png']
diverLeft=5*['diveLeft.png']
#charectar with dog link https://ya-webdesign.com/download.html
dogRight=5*['doRight.png']
dogLeft=5*['doLeft.png']
#https://www.cleanpng.com/png-barbecue-sauce-honey-mustard-dressing-barbecue-chi-6000705/
sausePic=5*['chickfiletsauce.png']
#https://www.hiclipart.com/free-transparent-background-png-clipart-devlq
falafelPic=5*['falafel.png']
#burger link
#https://www.foxnews.com/food-drink/we-tried-ihops-new-pancake-burger
burgerChPic='BURGER.png'
#https://favpng.com/png_view/fries-png-mcdonalds-french-fries-hamburger-fast-food-png/2cUtpVcG
friesChPic='fries.png'
#https://www.pngguru.com/free-transparent-background-png-clipart-kided
colaChPic='cola.png'
#http://www.pngall.com/cookie-png
cookieChPic='cookie.png'
coinPic='coin.png'
#https://www.behance.net/gallery/46601081/Background-for-mobile-game
mainPgPic='MainPage.jpg'
#https://www.dexigner.com/news/32195
macPgPic='mac.jpg'
#https://pixabay.com/photos/supermarket-stalls-coolers-market-949913/
shopPic='shop.jpg'
#https://www.123rf.com/photo_100264511_clear-blue-transparent-beach-water-background.html
sea='sea.jpg'
################## fonts ################
################## Varibales ############
#each enemy have different (vel,x,y,start,end,width) variables
#g(goast), s(scprpion), d(dog with the monster)
#each player has different(x,y,start,end,width) Vel stand for step
vel=50
step=50
wndW=551
wndH=750
chX1=wndW/2+vel//2
chY1=wndH-vel
chY2=chY1
chX2=chX1+vel
eEnd=wndW
ex=0
sY1=step
sW=42
e2=4*step
gW=33
gY1=2*step
e3Start=100
e3End=wndW-100
dY=7*step
eH=45
sY2=9*step
gX2=75
gStart2=75
gEnd2=wndW
gY2=11*step
dStart2=0
dEnd2=wndW-200
dY2=3*step
dW=45
numEnemies=6
rE=[]
rVD=[]
bgY1=0
bgY2=wndH*-1
bgY3=2*wndH*-1
############Random LOOPS##############
for i in range(numEnemies):
    rVD=rVD+[random.randint(1,10)]
    rE=rE+[random.randint(400,550)]
#the popup text x and y 
textX=wndW-100
textY=wndH-30
#########################################
#the caption and screen created
pygame.display.set_caption("CROSSIN'")
screen=pygame.display.set_mode((wndW,wndH))
#font and messages created and assigned  
font = pygame.font.Font('freesansbold.ttf', 30)
w1=font.render('PLAYER1 WON close screen to exit', True,[0,255,0])
w2=font.render('PLAYER2 WON close screen to exit', True,[0,255,0])
#the while loops main varbles created
gameOver=True
clScreen=False
clock=pygame.time.Clock()
#the class to create background 
class background:
    def __init__(self,backPic,x,y,screen):
        self.backPic=pygame.image.load(backPic).convert()
        self.x=x
        self.y=y
        self.screen=screen
    def draw(self):
        self.screen.blit(self.backPic,(self.x,self.y))
#the class to create charcters 
class player:
    def __init__(self,chX,chY,vel,chPic):
        self.chX=chX
        self.chY=chY
        self.chPic=chPic
        self.vel=vel
        self.box=(self.chX,self.chY,50,45)
    def draw(self,screen):
        self.chLoad=pygame.image.load(self.chPic).convert_alpha(screen)
        screen.blit(self.chLoad,[self.chX,self.chY])
        self.box=(self.chX,self.chY,50,45)
        #pygame.draw.rect(screen,[0,0,255],self.box,2)            
            
#the class to create enemies
class enemy:
    def __init__(self,rightPics,leftPics,y,x,vel,start,end,screen,w,boxH):
        self.x=x
        self.w=w
        self.y=y
        self.boxH=boxH
        self.vel=vel
        self.end=end
        self.start=start
        self.rightPics=rightPics
        self.leftPics=leftPics
        self.end=end
        self.xCount=0
        self.steps=0
        self.ratio=0
        self.box=(self.x,self.y,self.w,self.boxH)
#the function will take care of movment
    def movment(self):
        if self.xCount+1>=self.steps:
            self.xCount=0
        if self.vel>0:
            if self.x+self.vel+self.w<self.end:
                self.x=self.x+self.vel
                self.xCount+=1
            else:
                self.vel=self.vel*-1
                self.xCount=0
        elif self.vel<0:
            if self.x>self.start:
                self.x=self.x+self.vel
                self.xCount+=1
            else:
                self.vel=self.vel*-1
                self.xCount=0
#the function would create the pictures change
    def pics(self,screen):
        self.movment()
        self.steps=(self.end-self.start)//self.vel
        self.ratio=round(self.steps/len(self.rightPics))
        self.curX=(self.xCount//self.ratio)
        if self.curX>len(self.rightPics)-1:
            self.curX=len(self.rightPics)-1
        if self.vel>0:
            self.picR=pygame.image.load(self.rightPics[self.curX]).convert_alpha(screen)
            screen.blit(self.picR,[self.x,self.y])
        if self.vel<=0:
            self.picL=pygame.image.load(self.leftPics[self.curX]).convert_alpha(screen)
            screen.blit(self.picL,[self.x,self.y])
        self.box=(self.x,self.y,self.w,45)
        #pygame.draw.rect(screen,[0,0,255],self.box,2)
   

class coin:
    def __init__(self,coinPic,wndW,screen):
        self.coinPic=coinPic
        self.y=random.randint(-475,725)
        self.x=random.randint(0,wndW-25)
        self.coinLoad=pygame.image.load(coinPic).convert_alpha(screen)
        self.box=(self.x,self.y,25,25)
    def draw(self,screen):
        screen.blit(self.coinLoad,[self.x,self.y])
        self.box=(self.x,self.y,25,25)
#the objects are created bellow
shopPg=background(shopPic,0,0,screen)

mainPg1=background(mainPgPic,0,0,screen)

mMainPg=background(mMainPgPic,0,0,screen)

oMainPg=background('sea2.jpg',0,0,screen)

dMainPg=background(dMainPgPic,0,0,screen)

rMainPg=background('grassM.jpg',0,0,screen)

dMP=background(dMainPgPic,0,0,screen)

bgD1=background(backPicDes,0,bgY1,screen)

bgD2=background(backPicDes,0,bgY2,screen)

bgD3=background(backPicDes,0,bgY3,screen)

bgO1=background(sea,0,bgY1,screen)

bgO2=background(sea,0,bgY2,screen)

bgO3=background(sea,0,bgY3,screen)

bgR1=background('grass.jpg',0,bgY1,screen)

bgR2=background('grass.jpg',0,bgY2,screen)

bgR3=background('grass.jpg',0,bgY3,screen)

bgM3=background('mac.jpg',0,bgY1,screen)

bgM1=background(mBg1,0,bgY2,screen)

bgM2=background(mBg3,0,bgY3,screen)

d1=enemy(dogRight,dogLeft,-500,50,rVD[0],50,rE[0],screen,dW,eH)

d3=enemy(dogRight,dogLeft,-100,0,rVD[5],0,rE[5],screen,dW,eH)

s1=enemy(scorpionRight,scorpionLeft,sY1,80,rVD[1],80,rE[1],screen,sW,eH)

s3=enemy(scorpionRight,scorpionLeft,-200,80,rVD[1],80,rE[1],screen,sW,eH)

s4=enemy(scorpionRight,scorpionLeft,-300,80,rVD[1],80,rE[1],screen,sW,eH)

g1=enemy(goastRight,goastLeft,gY1,40,rVD[2],40,rE[2],screen,gW,eH)

g3=enemy(goastRight,goastLeft,-50,40,rVD[2],40,rE[2],screen,gW,eH)

g2=enemy(goastRight,goastLeft,gY2,30,rVD[3],30,rE[3],screen,gW,eH)

s2=enemy(scorpionRight,scorpionLeft,sY2,90,rVD[4],90,rE[4],screen,sW,eH)

d2=enemy(dogRight,dogLeft,dY2,0,rVD[5],0,rE[5],screen,dW,eH)

kfc1=enemy(kfcRight,kfcLeft,150,0,10,0,550,screen,100,eH)

kfc2=enemy(kfcRight,kfcLeft,600,0,11,0,550,screen,100,eH)

kfc3=enemy(kfcRight,kfcLeft,-200,0,12,0,550,screen,100,eH)

kfc4=enemy(kfcRight,kfcLeft,-350,0,15,0,550,screen,100,eH)

falafel1=enemy(falafelPic,falafelPic,100,0,8,0,550,screen,71,eH)

falafel2=enemy(falafelPic,falafelPic,450,0,9,0,550,screen,71,eH)

falafel3=enemy(falafelPic,falafelPic,700,0,9,0,550,screen,71,eH)

falafel4=enemy(falafelPic,falafelPic,-750,0,18,0,550,screen,71,eH)

sause1=enemy(sausePic,sausePic,400,0,6,0,550,screen,26,eH)

sause2=enemy(sausePic,sausePic,500,0,6,0,550,screen,26,eH)

sause3=enemy(sausePic,sausePic,-150,0,8,0,550,screen,26,eH)

sause4=enemy(sausePic,sausePic,-550,0,12,0,550,screen,26,eH)

sause5=enemy(sausePic,sausePic,-500,0,12,0,550,screen,26,eH)

shawarma1=enemy(shawarmaRight,shawarmaLeft,300,50,5,50,500,screen,133,eH)

shawarma2=enemy(shawarmaRight,shawarmaLeft,-250,0,5,0,500,screen,133,eH)

shawarma3=enemy(shawarmaRight,shawarmaLeft,-300,100,5,100,500,screen,133,eH)

shawarma4=enemy(shawarmaRight,shawarmaLeft,-450,50,9,50,500,screen,133,eH)

shawarma5=enemy(shawarmaRight,shawarmaLeft,-700,0,15,0,550,screen,133,eH)

diver1=enemy(diverRight,diverLeft,-250,0,15,0,550,screen,58,eH)
diver2=enemy(diverRight,diverLeft,350,0,13,0,550,screen,58,eH)
diver3=enemy(diverRight,diverLeft,200,0,15,0,550,screen,58,eH)
diver4=enemy(diverRight,diverLeft,-700,0,15,0,550,screen,58,eH)

shark1=enemy(sharkRight,sharkLeft,-50,0,20,0,550,screen,113,eH)
shark2=enemy(sharkRight,sharkLeft,150,0,20,0,550,screen,113,eH)
shark3=enemy(sharkRight,sharkLeft,-500,0,20,0,550,screen,113,eH)

fish1=enemy(fishRight,fishLeft,250,0,10,0,550,screen,103,eH)
fish2=enemy(fishRight,fishLeft,400,0,10,0,550,screen,103,eH)
fish3=enemy(fishRight,fishLeft,-800,0,10,0,550,screen,103,eH)

#https://www.exportersindia.com/sarfaraz-gamer-point/car-toy-4988283.htm
#https://www.freepik.com/premium-photo/red-model-toy-car-isolated-white-backg
#round-side-view-soft-focus_4905421.htm


car1=enemy(3*['CarsRight.png'],3*['carsLeft.png'],650,0,20,0,550,screen,96,eH)
car2=enemy(3*['rightFerrari.png'],3*['leftFerrari.png'],600,0,25,0,550,screen,179,eH)
car3=enemy(3*['rightFerrari.png'],3*['leftFerrari.png'],550,0,25,0,550,screen,179,eH)
car4=enemy(3*['CarsRight.png'],3*['carsLeft.png'],500,0,30,0,550,screen,96,eH)
car5=enemy(3*['CarsRight.png'],3*['carsLeft.png'],450,0,30,0,550,screen,96,eH)
truck1=enemy(3*['truckRight.png'],3*['truckLeft.png'],350,0,25,0,550,screen,89,eH)
truck2=enemy(3*['truckRight.png'],3*['truckLeft.png'],250,0,17,0,550,screen,89,eH)
ball1=enemy(3*['ballPic.png'],3*['ballPic.png'],100,0,19,0,550,screen,50,eH)
ball2=enemy(3*['ballPic.png'],3*['ballPic.png'],150,0,21,0,550,screen,50,eH)






burgerCh1=player(chX1,chY1,vel,burgerChPic)
burgerCh2=player(chX2,chY2,vel,burgerChPic)

cookieCh1=player(chX1,chY1,vel,cookieChPic)
cookieCh2=player(chX2,chY2,vel,cookieChPic)

colaCh1=player(chX1,chY1,vel,colaChPic)
colaCh2=player(chX2,chY2,vel,colaChPic)

friesCh1=player(chX1,chY1,vel,friesChPic)
friesCh2=player(chX2,chY2,vel,friesChPic)

enDes={d1:0,s1:1,g1:2,g2:3,s2:4,d2:5,s4:6,s3:7,g3:8,d3:9}
eDY=[-500,sY1,gY1,gY2,sY2,dY2,-300,-200,-50,-100]
eDx=[50,80,40,30,90,0,80,80,40,0]
enO={diver1:0,diver2:1,diver3:2,diver4:3,shark1:4,shark2:5,
shark3:6,fish1:7,fish2:8,fish3:9}
eOX=[0,0,0,0,0,0,0,0,0,0]
enM={kfc1:0,kfc2:1,kfc3:2,falafel1:3,falafel2:4,falafel3:5,sause1:6,
sause2:7,sause3:8,shawarma1:9,shawarma2:10,shawarma3:11,shawarma4:12,
kfc4:13,sause4:14,sause5:15,shawarma5:16,falafel4:17}
enR={car1:0,car2:1,car3:2,car4:3,car5:4,truck1:5,truck2:6,ball1:7,ball2:8}
eMY=[150,600,-200,100,450,700,400,500,-150,300,-250,-300,-450,
-350,-550,-600,-700,-750]
eMX=[0,0,0,0,0,0,0,0,0,50,0,100,50,0,0,0,0,0,0]
eOY=[-250,350,200,-700,-50,150,-500,250,400,-800]
eRY=[650,600,550,500,450,350,250,100,150]
eRX=[0,0,0,0,0,0,0,0,0]
coinsNum=random.randint(10,20)
coinsDic={}
for i in range(coinsNum):
    k=coin(coinPic,wndW,screen)
    coinsDic[k]=str(i)

#this function is used for one player mode
def movment1Ch(event,ch1,vel,wndW,wndH,steps,counter,steps2,en,ch2,step,coinsDic,bg1,bg2,bg3):
#the movment for the first player
         if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT and ch1.chX>vel:
                 ch1.chX=ch1.chX-vel
            if event.key==pygame.K_RIGHT and wndW-(2*vel)>ch1.chX:
                ch1.chX=ch1.chX+vel
            if event.key==pygame.K_UP and vel<ch1.chY:
                if steps>counter:
                    ch1.chY=ch1.chY-vel
                redrawPg(ch1,ch2,en,vel,counter,steps2,steps,step,coinsDic,bg1,bg2,bg3)
                return 1
            
#the function is for the two players mode           
def movment2Ch(ch2,ch1,event,wndH,wndW):             
    if event.type==pygame.KEYDOWN:
        if event.key==pygame.K_a and ch2.chX>vel:
            ch2.chX=ch2.chX-vel
        if event.key==pygame.K_d and wndW-(2*vel)>ch2.chX:
            ch2.chX=ch2.chX+vel
        if event.key==pygame.K_w and vel<ch2.chY:
            ch2.chY=ch2.chY-vel
        if event.key==pygame.K_s and wndH-(vel)>ch2.chY:
            ch2.chY=ch2.chY+vel
        if event.key==pygame.K_LEFT and ch1.chX>vel:
            ch1.chX=ch1.chX-vel
        if event.key==pygame.K_RIGHT and wndW-(2*vel)>ch1.chX:
            ch1.chX=ch1.chX+vel
        if event.key==pygame.K_UP and vel<ch1.chY:
            ch1.chY=ch1.chY-vel
        if event.key==pygame.K_DOWN and wndH-(vel)>ch1.chY:
            ch1.chY=ch1.chY+vel
####################################################
coins=100

burgerBought=True
colaBought=False
cookieBought=False
friesBought=False

burgerOn=True
colaOn=False
cookieOn=False
friesOn=False
shopPg1={0:shopPg}
mMainPg1={0:mMainPg}
dMainPg1={0:dMainPg}
rMainPg1={0:rMainPg}
oMainPg1={0:oMainPg}
mainPg11={0:mainPg1}

burgerCh={1:burgerCh1,2:burgerCh2}
cookieCh={1:cookieCh1,2:cookieCh2}
friesCh={1:friesCh1,2:friesCh2}
colaCh={1:colaCh1,2:colaCh2}

ch=burgerCh

shiledCount=0
allValMac=[mMainPg1,bgM1,bgM2,bgM3,enM,eMY,eMX]
allValDes=[dMainPg1,bgD1,bgD2,bgD3,enDes,eDY,eDx]
allValR=[rMainPg1,bgR1,bgR2,bgR3,enR,eRY,eRX]
allValO=[oMainPg1,bgO1,bgO2,bgO3,enO,eOY,eOX]
allValOther=[mainPg11,ch,screen,wndW,vel,wndH,w2,w1,step,coinPic,
coinsDic,bgY1,bgY2,bgY3,coins]
allValShop=[burgerBought,colaBought,cookieBought,friesBought,
burgerOn,colaOn,cookieOn,friesOn,burgerCh,colaCh,cookieCh,friesCh,
shiledCount,shopPg1]
##################################################
#this function is for mac level main page
def secMainPgM(allValMac,allValDes,allValR,allValO,allValOther,allValShop):
    clScreen=False
    while not clScreen:
        allValMac[0].get(0).draw()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_s:
                    key='One'
                    mLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
                if event.key==pygame.K_t:
                    key='Two'
                    mLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
        pygame.display.update()
#this function is for desert level main page
def secMainPgD(allValMac,allValDes,allValR,allValO,allValOther,allValShop):
    clScreen=False
    while not clScreen:
        allValDes[0].get(0).draw()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_s:
                    key='One'
                    dLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
                if event.key==pygame.K_t:
                    key='Two'
                    dLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
        pygame.display.update()
#this function is for playground level main page
def secMainPgR(allValMac,allValDes,allValR,allValO,allValOther,allValShop):
    clScreen=False
    while not clScreen:
        allValR[0].get(0).draw()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_s:
                    key='One'
                    rLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
                if event.key==pygame.K_t:
                    key='Two'
                    rLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
        pygame.display.update()
#this function is for ocean level main page
def secMainPgO(allValMac,allValDes,allValR,allValO,allValOther,allValShop):
    clScreen=False
    while not clScreen:
        (allValO[0].get(0)).draw()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_s:
                    key='One'
                    oLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
                if event.key==pygame.K_t:
                    key='Two'
                    oLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop)
                    clScreen=True
        pygame.display.update()
#this function is for shop page
def secMainPgS(allValMac,allValDes,allValR,allValO,allValOther,allValShop):
    shopCl=False
    while not shopCl:
        for event in pygame.event.get():
            allValShop[13].get(0).draw()
            font=pygame.font.SysFont('serif',30,True)
            text=font.render('Total Coins: ' +str(allValOther[14]),1,[0,0,0])
            screen.blit(text,(0,10))
            text2=font.render('Total Shileds: ' +str(allValShop[12]),1,[0,0,0])
            screen.blit(text2,(0,50))
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_b:
                     allValOther[1]=allValShop[8]
                if event.key==pygame.K_c:
                    if allValOther[14]>=100 and allValShop[1]==False:
                        allValOther[14]=allValOther[14]-100
                        allValShop[1]=True
                        allValOther[1]=allValShop[9]
                    if allValShop[1]==True:
                        allValOther[1]=allValShop[9]
                if event.key==pygame.K_k and allValShop[2]==False:
                    if allValOther[14]>=100:
                        allValOther[14]=allValOther[14]-100
                        allValShop[2]=True
                        allValOther[1]=allValShop[10]
                    if allValShop[2]==True:
                         allValOther[1]=allValShop[10]
                if event.key==pygame.K_f:
                    if allValOther[14]>=100 and allValShop[3]==False:
                        allValOther[14]=allValOther[14]-100
                        allValShop[3]=True
                        allValOther[1]=allValShop[11]
                    if allValShop[3]==True:
                        allValOther[1]=allValShop[11]
                if event.key==pygame.K_m:
                    shopCl=True
        pygame.display.update()
        pygame.display.flip()
    if shopCl==True:
        mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
            
#this function is for the game main page                
def mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop):
    page=False
    while not page:
        (allValOther[0].get(0)).draw()
        font=pygame.font.SysFont('serif',30,True)
        text=font.render('Total Coins: ' +str(allValOther[14]),1,[0,0,0])
        screen.blit(text,(0,10))
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                quit()
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_d:
                    secMainPgD(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
                    page=True
                if event.key==pygame.K_m:
                    secMainPgM(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
                    page=True
                if event.key==pygame.K_r:
                    secMainPgR(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
                    page=True
                if event.key==pygame.K_o:
                    secMainPgO(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
                    page=True
                if event.key==pygame.K_s:
                    secMainPgS(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
                    page=True
        pygame.display.update()
        pygame.display.flip()



#this functions will draw all of chaterters and enemies on the game screen
def draw(screen,count,en,ch1,ch2,coinsDic,bg1,bg2,bg3,coinsT,coinFont,shileds):
    bg1.draw()
    bg2.draw()
    bg3.draw()
    text=coinFont.render('Total Coins: ' +str(coinsT),1,[0,0,0])
    screen.blit(text,(0,10))
    ch1.draw(screen)
    for i in en:
        i.pics(screen)
    if count==2:
        ch2.draw(screen)
    for i in coinsDic.keys():
        i.draw(screen)
    

#the clash function will detect the clashes between chaterters and enemies
def clash(en,p,pt,count,ey,shield):
    if count==1:
        for e in en.keys():
#if one player clash enemy return game Over 
            if p.box[1]<e.box[1]+e.box[3] and p.box[1]+p.box[3]>e.box[1]:
                if p.box[0]+p.box[2]>e.box[0] and p.box[0]<e.box[0]+e.box[2]:
                    return True
#if one of the two chaterters clash with enemy then the chaterter restart thier position 

    if count!=1:
        for e in en.keys():
            if p.box[1]<e.box[1]+e.box[3] and p.box[1]+p.box[3]>e.box[1]:
                if p.box[0]+p.box[2]>e.box[0] and p.box[0]<e.box[0]+e.box[2]:
                    p.chY=chY1
                    p.chX=chX1
            if pt.box[1]<e.box[1]+e.box[3] and pt.box[1]+pt.box[3]>e.box[1]:
                if pt.box[0]+pt.box[2]>e.box[0] and pt.box[0]<e.box[0]+e.box[2]:
                    pt.chY=chY2
                    pt.chX=chX2
#this function is for the win screens                   
def winScreen(ch2,ch1):
    if ch2.chY<55:
        screen.fill([255,255,255])
        screen.blit(w2,(0,350))
        pygame.display.update()
        winner=True
    if ch1.chY<55:
        screen.fill([255,255,255])
        screen.blit(w1,(0,350))
        pygame.display.update()
        winner=True
        
def gameOverScreen():
        gO=font.render('GAME OVER', True,[255,0,0])
        screen.fill([255,255,255])
        screen.blit(gO,(0,350))
        pygame.display.update()
    
def redrawPg(ch1,ch2,en,vel,counter,steps2,steps,step,coinsDic,bg1,bg2,bg3):
    if steps<counter or steps2<counter:
        en=list(en)
        for i in en:
            i.y=i.y+step
        for i in coinsDic.keys():
            i.y=i.y+step
    bg1.y=bg1.y+step
    bg2.y=bg2.y+step
    bg3.y=bg3.y+step
    
def coinsCount(p,coinsDic):
    coinsDic1=coinsDic
    for coin in coinsDic1.keys():
        if p.box[1]<coin.box[1]+coin.box[3] and p.box[1]+p.box[3]>coin.box[1]:
            if p.box[0]+p.box[2]>coin.box[0] and p.box[0]<coin.box[0]+coin.box[2]:
                del coinsDic1[coin]
                return 1
    
def dLoop(allValMac,allValDes,allValR,allValO,allValOther,key,allValShop):
    d=allValDes
    o=allValOther
    shiled=allValShop[12]
    coinF=pygame.font.SysFont('serif',30,True)
    ch1=allValOther[1].get(1)
    ch2=allValOther[1].get(2)
    #reset the first chaterter posion 
    ch1.chY=chY1
    ch1.chX=chX1
    steps=0
    steps2=0
    counter=2
    coinsT=0
    x1=0
    x2=0
#this two if condtions would check the number of players and adjst count
    if'Two'in key:
        gameOver=False
        winner=gameOver
        pNum=2
        ch2.chY=chY2
        ch2.chX=chX2
    if'One'in key:
        gameOver=False
        winner=gameOver
        pNum=1
    while not gameOver and not winner:
#this functions would draw the charecters
        draw(o[2],pNum,d[4],ch1,ch2,o[10],d[1],d[2],d[3],coinsT,coinF,shiled)
        winScreen(ch2,ch1)
#if the one charters crash with enemy gameOver will be False
        if clash(d[4],ch1,ch2,pNum,d[5],allValShop[12])==True:
            for i in d[4].keys():
                i.y=d[5][d[4].get(i)]
                i.x=d[6][d[4].get(i)]
            gameOver=True
        coinDetect=coinsCount(ch1,o[10])
        if coinDetect!=None:
            coinsT=coinsT+coinDetect
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                gameOver=True
            if pNum==1:
                x1=movment1Ch(event,ch1,o[4],o[3],o[5],steps,counter,steps2,d[4],ch2,o[8],o[10],d[1],d[2],d[3])
                if x1 !=None:
                    steps=steps+x1                    
            else:
               movment2Ch(ch2,ch1,event,o[5],o[3])
        pygame.display.flip()
        pygame.display.update()
#if the game ended the function would be recresivlly called to main page
    if gameOver==True:
        d[1].y=allValOther[11]
        d[2].y=allValOther[12]
        d[3].y=allValOther[13]
        gameOverScreen()
        allValOther[14]=allValOther[14]+coinsT
        mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop)


def mLoop(allValMac,allValDes,allValR,allvalO,allValOther,key,allValShop):
    d=allValMac
    o=allValOther
    coinFont=pygame.font.SysFont('serif',30,True)
    ch1=allValOther[1].get(1)
    ch2=allValOther[1].get(2)
    #reset the first chaterter posion 
    ch1.chY=chY1
    ch1.chX=chX1
    steps=0
    steps2=0
    counter=5
    coinsT=0
    x1=0
    x2=0
#this two if condtions would check the number of players and adjst count
    if'Two'in key:
        gameOver=False
        winner=gameOver
        pNum=2
        ch2.chY=chY2
        ch2.chX=chX2
    if'One'in key:
        gameOver=False
        winner=gameOver
        pNum=1
    while not gameOver and not winner:
#this functions would draw the charecters
        draw(o[2],pNum,d[4],ch1,ch2,o[10],d[1],d[2],d[3],coinsT,coinFont,allValShop[12])
        winScreen(ch2,ch1)
#if the one charters crash with enemy gameOver will be False
        if clash(d[4],ch1,ch2,pNum,d[5],allValShop[12])==True:
            for i in d[4].keys():
                i.y=d[5][d[4].get(i)]
                i.x=d[6][d[4].get(i)]
            gameOver=True
        coinDetect=coinsCount(ch1,o[10])
        if coinDetect!=None:
            coinsT=coinsT+coinDetect
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                gameOver=True
            if pNum==1:
                x1=movment1Ch(event,ch1,o[4],o[3],o[5],steps,counter,steps2,d[4],ch2,o[8],o[10],d[1],d[2],d[3])
                if x1 !=None:
                    steps=steps+x1                    
            else:
               movment2Ch(ch2,ch1,event,o[5],o[3])
        pygame.display.flip()
        pygame.display.update()
#if the game ended the function would be recresivlly called to main page
    if gameOver==True:
        d[1].y=allValOther[11]
        d[2].y=allValOther[12]
        d[3].y=allValOther[13]
        gameOverScreen()
        allValOther[14]=allValOther[14]+coinsT
        mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop)


def rLoop(allValMac,allValDes,allValR,allvalO,allValOther,key,allValShop):
    d=allValR
    o=allValOther
    ch1=allValOther[1].get(1)
    ch2=allValOther[1].get(2)
    coinFont=pygame.font.SysFont('serif',30,True)
    #reset the first chaterter posion 
    ch1.chY=chY1
    ch1.chX=chX1
    steps=0
    steps2=0
    counter=-1
    coinsT=0
    x1=0
    x2=0
#this two if condtions would check the number of players and adjst count
    if'Two'in key:
        gameOver=False
        winner=gameOver
        pNum=2
        ch2.chY=chY2
        ch2.chX=chX2
    if'One'in key:
        gameOver=False
        winner=gameOver
        pNum=1
    while not gameOver and not winner:
#this functions would draw the charecters
        draw(o[2],pNum,d[4],ch1,ch2,o[10],d[1],d[2],d[3],coinsT,coinFont,allValShop[12])
        winScreen(ch2,ch1)
#if the one charters crash with enemy gameOver will be False
        if clash(d[4],ch1,ch2,pNum,d[5],allValShop[12])==True:
            for i in d[4].keys():
                i.y=d[5][d[4].get(i)]
                i.x=d[6][d[4].get(i)]
            gameOver=True
        coinDetect=coinsCount(ch1,o[10])
        if coinDetect!=None:
            coinsT=coinsT+coinDetect
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                gameOver=True
            if pNum==1:
                x1=movment1Ch(event,ch1,o[4],o[3],o[5],steps,counter,steps2,d[4],ch2,o[8],o[10],d[1],d[2],d[3])
                if x1 !=None:
                    steps=steps+x1                    
            else:
               movment2Ch(ch2,ch1,event,o[5],o[3])
        pygame.display.flip()
        pygame.display.update()
#if the game ended the function would be recresivlly called to main page
    if gameOver==True:
        d[1].y=allValOther[11]
        d[2].y=allValOther[12]
        d[3].y=allValOther[13]
        gameOverScreen()
        allValOther[14]=allValOther[14]+coinsT
        mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop)

        
def oLoop(allValMac,allValDes,allValR,allvalO,allValOther,key,allValShop):
    d=allValO
    o=allValOther
    ch1=allValOther[1].get(1)
    ch2=allValOther[1].get(2)
    coinFont=pygame.font.SysFont('serif',30,True)
    #reset the first chaterter posion 
    ch1.chY=chY1
    ch1.chX=chX1
    steps=0
    steps2=0
    counter=5
    coinsT=0
    x1=0
    x2=0
#this two if condtions would check the number of players and adjst count
    if'Two'in key:
        gameOver=False
        winner=gameOver
        pNum=2
        ch2.chY=chY2
        ch2.chX=chX2
    if'One'in key:
        gameOver=False
        winner=gameOver
        pNum=1
    while not gameOver and not winner:
#this functions would draw the charecters
        draw(o[2],pNum,d[4],ch1,ch2,o[10],d[1],d[2],d[3],coinsT,coinFont,allValShop[12])
        winScreen(ch2,ch1)
        if clash(d[4],ch1,ch2,pNum,d[5],allValShop[12])==True:
            for i in d[4].keys():
                i.y=d[5][d[4].get(i)]
                i.x=d[6][d[4].get(i)]
            gameOver=True
        coinDetect=coinsCount(ch1,o[10])
        if coinDetect!=None:
            coinsT=coinsT+coinDetect
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                gameOver=True
            if pNum==1:
                x1=movment1Ch(event,ch1,o[4],o[3],o[5],steps,counter,steps2,d[4],ch2,o[8],o[10],d[1],d[2],d[3])
                if x1 !=None:
                    steps=steps+x1                    
            else:
               movment2Ch(ch2,ch1,event,o[5],o[3])
        pygame.display.flip()
        pygame.display.update()
#if the game ended the function would be recresivlly called to main page
    if gameOver==True:
        d[1].y=allValOther[11]
        d[2].y=allValOther[12]
        d[3].y=allValOther[13]
        allValOther[14]=allValOther[14]+coinsT
        gameOverScreen()
        mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop)


mainPg(allValMac,allValDes,allValR,allValO,allValOther,allValShop)
